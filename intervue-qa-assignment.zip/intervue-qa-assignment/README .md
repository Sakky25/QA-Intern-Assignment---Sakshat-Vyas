# Intervue.io Login Automation

## 📋 Requirements
- Python 3.x
- Selenium
- Chrome + ChromeDriver

## 🚀 Setup
```bash
pip install selenium
