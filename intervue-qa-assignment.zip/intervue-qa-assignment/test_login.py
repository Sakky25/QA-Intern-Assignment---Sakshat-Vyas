from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time

# Setup
driver = webdriver.Chrome()  # You can specify the executable_path if needed
driver.maximize_window()
driver.get("https://www.intervue.io")

time.sleep(2)

try:
    # Click on "Login" button
    login_button = driver.find_element(By.LINK_TEXT, "Login")
    login_button.click()

    time.sleep(3)

    # Enter credentials
    email_input = driver.find_element(By.NAME, "email")
    password_input = driver.find_element(By.NAME, "password")

    email_input.send_keys("neha@intervue.io")
    password_input.send_keys("Ps@neha@123")

    # Submit login
    password_input.send_keys(Keys.RETURN)

    time.sleep(5)

    # Check for failed login
    if "login" in driver.current_url.lower():
        driver.save_screenshot("login_failed.png")
        print("Login failed. Screenshot saved.")
    else:
        print("Login successful.")

except Exception as e:
    print("Error:", e)
    driver.save_screenshot("error.png")

driver.quit()
